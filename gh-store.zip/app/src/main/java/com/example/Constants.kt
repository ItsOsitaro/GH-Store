package com.example

object Constants {
    // Replace this with your own fine-grained GitHub token before building.
    // Do not commit real tokens to a public source repo.
    const val DEFAULT_GITHUB_TOKEN = "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" 

    const val APPS_LIST_URL = "https://raw.githubusercontent.com/ItsOsitaro/GitHub-Store/main/apps.txt"
}
