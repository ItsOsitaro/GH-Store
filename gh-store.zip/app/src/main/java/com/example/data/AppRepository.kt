package com.example.data

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

import kotlinx.coroutines.flow.flow
import okhttp3.OkHttpClient
import okhttp3.Request
import okio.buffer
import okio.sink
import java.io.File

class AppRepository(
    private val appDao: AppDao,
    private val apiService: GithubApiService,
    private val settingsManager: SettingsManager,
    private val moshi: Moshi,
    private val context: Context,
    private val okHttpClient: OkHttpClient
) {

    private val _syncStatus = MutableStateFlow<SyncStatus>(SyncStatus.Idle)
    val syncStatus: StateFlow<SyncStatus> = _syncStatus

    private val mutex = Mutex()
    private var isRateLimited = false

    fun getAllApps(): Flow<List<AppEntity>> = appDao.getAllApps()

    fun getAppFlow(repoFullName: String): Flow<AppEntity?> = appDao.getAppByIdFlow(repoFullName)

    suspend fun clearCache() {
        appDao.deleteAllApps()
        settingsManager.setETag(null)
    }

    suspend fun refreshInstallStates() = withContext(Dispatchers.IO) {
        val allApps = appDao.getAllAppsList()
        for (app in allApps) {
            val packageName = app.packageName
            if (!packageName.isNullOrBlank()) {
                var newInstallState = InstallState.NOT_INSTALLED
                try {
                    val packageInfo = context.packageManager.getPackageInfo(packageName, 0)
                    val installedVersionName = packageInfo.versionName?.trim()?.removePrefix("v")?.removePrefix("V")
                    val normalizedLatestTag = app.latestTag?.trim()?.removePrefix("v")?.removePrefix("V")
                    
                    if (installedVersionName != null && normalizedLatestTag != null) {
                        if (installedVersionName == normalizedLatestTag) {
                            newInstallState = InstallState.INSTALLED
                        } else {
                            newInstallState = InstallState.UPDATE_AVAILABLE
                        }
                    } else {
                        // If we can't parse versions, but app is installed, just show installed
                        newInstallState = InstallState.INSTALLED
                    }
                    
                    Log.d("UpdateCheck", "Package: $packageName | Installed: $installedVersionName | Latest: $normalizedLatestTag -> State: $newInstallState")
                    
                } catch (e: PackageManager.NameNotFoundException) {
                    newInstallState = InstallState.NOT_INSTALLED
                    Log.d("UpdateCheck", "Package: $packageName not installed")
                }
                
                if (app.installState != newInstallState) {
                    appDao.updateApp(app.copy(installState = newInstallState))
                }
            }
        }
    }

    suspend fun syncApps(forceRefresh: Boolean = false) {
        if (_syncStatus.value is SyncStatus.Syncing) return

        _syncStatus.value = SyncStatus.Syncing(message = "Fetching apps list...")
        isRateLimited = false

        try {
            val url = com.example.Constants.APPS_LIST_URL
            val eTag = if (forceRefresh) null else settingsManager.getETag()
            val response = apiService.fetchAppsTxt(url, eTag)

            val appsTxtContent = when (response.code()) {
                200 -> {
                    settingsManager.setETag(response.headers()["ETag"])
                    response.body()?.string() ?: ""
                }
                304 -> {
                    // Not modified, proceed with existing list
                    null
                }
                404 -> {
                    _syncStatus.value = SyncStatus.Error("Apps list not found (404)")
                    return
                }
                else -> {
                    _syncStatus.value = SyncStatus.Error("Failed to fetch apps list: ${response.code()}")
                    return
                }
            }

            // Parse valid lines
            val validRepos = mutableListOf<ParsedRepo>()
            if (appsTxtContent != null) {
                val lines = appsTxtContent.lines()
                for (line in lines) {
                    val trimmed = line.trim()
                    if (trimmed.isEmpty() || trimmed.startsWith("#") || !trimmed.contains("/")) continue
                    
                    val parts = trimmed.split(",")
                    val ownerRepo = parts[0].trim()
                    val packageName = parts.getOrNull(1)?.trim()
                    
                    validRepos.add(ParsedRepo(ownerRepo, packageName))
                }
                
                // Remove apps no longer in the list
                appDao.deleteAppsNotIn(validRepos.map { it.repoFullName })
            } else {
                // If 304, we don't have the text content, but we can query our local DB for the list of names
                // Wait, if it's 304, the list hasn't changed. We can just use the local DB's entries as our target list.
            }

            val targetReposToFetch = if (appsTxtContent != null) {
                validRepos
            } else {
                appDao.getAllAppsList().map { ParsedRepo(it.repoFullName, it.packageName) }
            }

            _syncStatus.value = SyncStatus.Syncing(message = "Fetching app details...")

            val currentTime = System.currentTimeMillis()
            val oneHourMillis = 60 * 60 * 1000L
            val userToken = settingsManager.getPat()
            val activeToken = if (!userToken.isNullOrBlank()) {
                userToken
            } else if (com.example.Constants.DEFAULT_GITHUB_TOKEN.isNotBlank()) {
                com.example.Constants.DEFAULT_GITHUB_TOKEN
            } else {
                null
            }
            val authHeader = activeToken?.let { "Bearer $it" }

            for ((index, repo) in targetReposToFetch.withIndex()) {
                if (isRateLimited) {
                    _syncStatus.value = SyncStatus.Error("GitHub rate limit reached, try again later")
                    break
                }

                _syncStatus.value = SyncStatus.Syncing(message = "Fetching details... (${index + 1}/${targetReposToFetch.size})")

                val parts = repo.repoFullName.split("/")
                val owner = parts[0]
                val repoName = parts[1]

                val existingApp = appDao.getAppById(repo.repoFullName)
                val packageName = repo.packageName ?: existingApp?.packageName
                
                var currentTag = existingApp?.latestTag
                var installState = InstallState.NOT_INSTALLED

                val lastFetched = existingApp?.lastFetchedAt ?: 0L
                val shouldFetch = forceRefresh || (currentTime - lastFetched > oneHourMillis)

                if (shouldFetch) {
                    delay(200) // Sequential fetch with delay

                    try {
                        val releaseResp = apiService.getLatestRelease(owner, repoName, authHeader)
                        
                        // Check rate limit
                        val rateLimitRemaining = releaseResp.headers()["X-RateLimit-Remaining"]?.toIntOrNull()
                        if (rateLimitRemaining == 0) {
                            isRateLimited = true
                            _syncStatus.value = SyncStatus.Error("GitHub rate limit reached, try again later")
                            break
                        }

                        var fetchStatus = FetchStatus.OK
                        var tag: String? = null
                        var date: String? = null
                        var notes: String? = null
                        val apkAssets = mutableListOf<ApkAsset>()

                        when (releaseResp.code()) {
                            200 -> {
                                val release = releaseResp.body()
                                tag = release?.tagName
                                currentTag = tag
                                date = release?.publishedAt
                                notes = release?.body
                                
                                val assets = release?.assets ?: emptyList()
                                for (asset in assets) {
                                    if (asset.name.endsWith(".apk", ignoreCase = true)) {
                                        apkAssets.add(ApkAsset(asset.name, asset.browserDownloadUrl, asset.size))
                                    }
                                }

                                if (apkAssets.isEmpty()) {
                                    fetchStatus = FetchStatus.NO_APK
                                }
                            }
                            404 -> {
                                fetchStatus = FetchStatus.NO_RELEASE
                            }
                            else -> {
                                fetchStatus = FetchStatus.ERROR
                            }
                        }

                        // Fetch repo metadata
                        var repoDesc: String? = existingApp?.description
                        var repoDisplayName: String? = existingApp?.displayName ?: repoName
                        
                        if (fetchStatus != FetchStatus.ERROR) {
                            val repoResp = apiService.getRepoMetadata(owner, repoName, authHeader)
                            if (repoResp.isSuccessful) {
                                val repoBody = repoResp.body()
                                repoDesc = repoBody?.description
                                repoDisplayName = repoBody?.name ?: repoName
                            }
                        }

                        // Update DB
                        val assetAdapter = moshi.adapter<List<ApkAsset>>(
                            Types.newParameterizedType(List::class.java, ApkAsset::class.java)
                        )
                        val assetsJson = if (apkAssets.isNotEmpty()) assetAdapter.toJson(apkAssets) else null
                        
                        // Prioritize arm64 or universal
                        var bestApkUrl: String? = null
                        if (apkAssets.isNotEmpty()) {
                            val best = apkAssets.find { it.name.contains("arm64", ignoreCase = true) }
                                ?: apkAssets.find { it.name.contains("universal", ignoreCase = true) }
                                ?: apkAssets.first()
                            bestApkUrl = best.downloadUrl
                        }

                        // Package manager check moved to refreshInstallStates()

                        val updatedApp = AppEntity(
                            repoFullName = repo.repoFullName,
                            packageName = packageName,
                            displayName = repoDisplayName,
                            description = repoDesc ?: notes, // fallback description to notes if null
                            latestTag = tag,
                            publishedAt = date,
                            apkDownloadUrl = bestApkUrl,
                            availableApkAssetsJson = assetsJson,
                            iconUrl = "https://github.com/$owner.png",
                            lastFetchedAt = currentTime,
                            fetchStatus = fetchStatus,
                            installState = installState
                        )
                        appDao.insertApp(updatedApp)
                        
                    } catch (e: Exception) {
                        Log.e("AppRepository", "Error fetching repo ${repo.repoFullName}", e)
                        if (existingApp != null) {
                             appDao.insertApp(existingApp.copy(fetchStatus = FetchStatus.ERROR))
                        }
                    }
                } else if (existingApp != null) {
                    if (existingApp.packageName != packageName) {
                         appDao.insertApp(existingApp.copy(packageName = packageName))
                    }
                }
            }

            if (!isRateLimited) {
                _syncStatus.value = SyncStatus.Idle
            }

        } catch (e: Exception) {
            Log.e("AppRepository", "Error syncing apps", e)
            _syncStatus.value = SyncStatus.Error(e.message ?: "Network error")
        }
    }

    fun downloadApk(url: String, title: String): Flow<DownloadState> = flow {
        emit(DownloadState.InProgress(0, 0, null))
        val request = Request.Builder().url(url).build()
        val call = okHttpClient.newCall(request)
        
        try {
            val response = withContext(Dispatchers.IO) { call.execute() }
            if (!response.isSuccessful) {
                emit(DownloadState.Error("HTTP Error ${response.code}"))
                return@flow
            }

            val body = response.body
            if (body == null) {
                emit(DownloadState.Error("Empty response body"))
                return@flow
            }

            val totalBytes = body.contentLength()
            val file = File(context.getExternalFilesDir(null), "$title.apk")
            var bytesDownloaded = 0L

            withContext(Dispatchers.IO) {
                body.source().use { source ->
                    file.sink().buffer().use { sink ->
                        val buffer = okio.Buffer()
                        var bytesRead: Long
                        while (source.read(buffer, 8192).also { bytesRead = it } != -1L) {
                            sink.write(buffer, bytesRead)
                            bytesDownloaded += bytesRead
                            val percent = if (totalBytes > 0) ((bytesDownloaded * 100) / totalBytes).toInt() else null
                            emit(DownloadState.InProgress(bytesDownloaded, totalBytes, percent))
                        }
                    }
                }
            }

            emit(DownloadState.Success(file))
        } catch (e: kotlinx.coroutines.CancellationException) {
            call.cancel()
            val file = File(context.getExternalFilesDir(null), "$title.apk")
            if (file.exists()) {
                file.delete()
            }
            emit(DownloadState.Cancelled)
            throw e
        } catch (e: Exception) {
            emit(DownloadState.Error(e.message ?: "Download failed"))
        }
    }
}

sealed class SyncStatus {
    object Idle : SyncStatus()
    data class Syncing(val message: String) : SyncStatus()
    data class Error(val message: String) : SyncStatus()
}

data class ParsedRepo(val repoFullName: String, val packageName: String?)
