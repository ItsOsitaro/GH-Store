package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM apps ORDER BY displayName COLLATE NOCASE ASC")
    fun getAllApps(): Flow<List<AppEntity>>

    @Query("SELECT * FROM apps")
    suspend fun getAllAppsList(): List<AppEntity>

    @Query("SELECT * FROM apps WHERE repoFullName = :repoFullName")
    suspend fun getAppById(repoFullName: String): AppEntity?

    @Query("SELECT * FROM apps WHERE repoFullName = :repoFullName")
    fun getAppByIdFlow(repoFullName: String): Flow<AppEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApp(app: AppEntity)

    @Update
    suspend fun updateApp(app: AppEntity)

    @Query("DELETE FROM apps WHERE repoFullName NOT IN (:repoNames)")
    suspend fun deleteAppsNotIn(repoNames: List<String>)
    
    @Query("DELETE FROM apps")
    suspend fun deleteAllApps()
}

@Database(entities = [AppEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao
}
