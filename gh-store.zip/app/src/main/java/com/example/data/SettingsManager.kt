package com.example.data

import android.content.Context
import androidx.core.content.edit
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SettingsManager(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val sharedPreferences = EncryptedSharedPreferences.create(
        context,
        "secure_settings",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getPat(): String? {
        return sharedPreferences.getString("github_pat", null)
    }

    fun setPat(pat: String?) {
        sharedPreferences.edit { putString("github_pat", pat) }
    }

    fun getETag(): String? {
        return sharedPreferences.getString("apps_txt_etag", null)
    }

    fun setETag(etag: String?) {
        sharedPreferences.edit { putString("apps_txt_etag", etag) }
    }
}
