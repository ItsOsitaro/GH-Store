package com.example.data

import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path
import retrofit2.http.Url

interface GithubApiService {
    @GET("repos/{owner}/{repo}/releases/latest")
    suspend fun getLatestRelease(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Header("Authorization") authHeader: String?
    ): Response<GithubRelease>

    @GET("repos/{owner}/{repo}")
    suspend fun getRepoMetadata(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Header("Authorization") authHeader: String?
    ): Response<GithubRepo>

    @GET
    suspend fun fetchAppsTxt(
        @Url url: String,
        @Header("If-None-Match") etag: String?
    ): Response<ResponseBody>
}
