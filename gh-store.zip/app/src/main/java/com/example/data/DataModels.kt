package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

enum class FetchStatus {
    OK, NO_RELEASE, NO_APK, ERROR, UNFETCHED
}

enum class InstallState {
    NOT_INSTALLED, INSTALLED, UPDATE_AVAILABLE
}

@Entity(tableName = "apps")
data class AppEntity(
    @PrimaryKey val repoFullName: String, // e.g. "owner/repo"
    val packageName: String?,
    val displayName: String?,
    val description: String?,
    val latestTag: String?,
    val publishedAt: String?,
    val apkDownloadUrl: String?,
    val availableApkAssetsJson: String?, // JSON array of ApkAsset
    val iconUrl: String?,
    val lastFetchedAt: Long = 0,
    val fetchStatus: FetchStatus = FetchStatus.UNFETCHED,
    val installState: InstallState = InstallState.NOT_INSTALLED
)

@JsonClass(generateAdapter = true)
data class ApkAsset(
    val name: String,
    val downloadUrl: String,
    val size: Long
)

// Retrofit Models

@JsonClass(generateAdapter = true)
data class GithubRelease(
    @param:Json(name = "tag_name") val tagName: String?,
    val name: String?,
    val body: String?,
    @param:Json(name = "published_at") val publishedAt: String?,
    val assets: List<GithubAsset>?
)

@JsonClass(generateAdapter = true)
data class GithubAsset(
    val name: String,
    @param:Json(name = "browser_download_url") val browserDownloadUrl: String,
    val size: Long
)

@JsonClass(generateAdapter = true)
data class GithubRepo(
    val name: String,
    val description: String?,
    val owner: GithubOwner?
)

@JsonClass(generateAdapter = true)
data class GithubOwner(
    @param:Json(name = "avatar_url") val avatarUrl: String?
)
