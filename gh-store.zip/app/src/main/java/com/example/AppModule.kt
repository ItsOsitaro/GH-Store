package com.example

import android.content.Context
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.AppRepository
import com.example.data.GithubApiService
import com.example.data.SettingsManager
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

class AppModule(private val context: Context) {
    
    val settingsManager by lazy { SettingsManager(context) }

    val moshi by lazy {
        Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()
    }

    private val okHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        OkHttpClient.Builder()
            .addInterceptor(logging)
            .build()
    }

    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.github.com/") // Base url required but we also use full url for apps.txt
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
    }

    val plainOkHttpClient by lazy {
        OkHttpClient.Builder().build()
    }

    val apiService: GithubApiService by lazy {
        retrofit.create(GithubApiService::class.java)
    }

    val database by lazy {
        Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "ghstore_db"
        )
        .fallbackToDestructiveMigration(dropAllTables = true)
        .build()
    }

    val repository by lazy {
        AppRepository(
            appDao = database.appDao(),
            apiService = apiService,
            settingsManager = settingsManager,
            moshi = moshi,
            context = context,
            okHttpClient = plainOkHttpClient
        )
    }
}
