package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.AppDetailScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val appModule by lazy { AppModule(applicationContext) }
    private val viewModel: MainViewModel by viewModels { MainViewModel.Factory(appModule) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavigation(viewModel)
                }
            }
        }
    }
}

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                viewModel = viewModel,
                onNavigateToDetail = { repoFullName ->
                    val encoded = java.net.URLEncoder.encode(repoFullName, "UTF-8")
                    navController.navigate("detail/$encoded")
                },
                onNavigateToSettings = {
                    navController.navigate("settings")
                }
            )
        }
        composable(
            route = "detail/{repoFullName}",
            arguments = listOf(navArgument("repoFullName") { type = NavType.StringType })
        ) { backStackEntry ->
            val repoFullName = backStackEntry.arguments?.getString("repoFullName")
            val decoded = repoFullName?.let { java.net.URLDecoder.decode(it, "UTF-8") }
            if (decoded != null) {
                AppDetailScreen(
                    viewModel = viewModel,
                    repoFullName = decoded,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
        composable("settings") {
            SettingsScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
