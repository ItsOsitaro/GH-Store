package com.example.ui.screens

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.net.toUri
import android.os.Environment
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.MainViewModel
import com.example.data.ApkAsset
import com.example.data.FetchStatus
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.File
import com.example.data.DownloadState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppDetailScreen(
    viewModel: MainViewModel,
    repoFullName: String,
    onNavigateBack: () -> Unit
) {
    val appFlow = remember(repoFullName) { viewModel.getAppFlow(repoFullName) }
    val app by appFlow.collectAsState(initial = null)
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(app?.displayName ?: "App Details", fontWeight = FontWeight.SemiBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                ),
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (app == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            val appEntity = app!!
            Column(
                modifier = Modifier
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        shadowElevation = 4.dp,
                        modifier = Modifier.size(80.dp)
                    ) {
                        AsyncImage(
                            model = appEntity.iconUrl,
                            contentDescription = "Icon",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(text = appEntity.displayName ?: appEntity.repoFullName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                        Text(text = "By ${appEntity.repoFullName.split("/")[0]}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                if (appEntity.fetchStatus == FetchStatus.OK) {
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.small) {
                            Text(text = appEntity.latestTag ?: "Unknown version", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.onSecondaryContainer, style = MaterialTheme.typography.labelMedium)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        if (appEntity.installState == com.example.data.InstallState.UPDATE_AVAILABLE) {
                            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.small) {
                                Text(text = "Update available", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.onPrimaryContainer, style = MaterialTheme.typography.labelMedium)
                            }
                        } else if (appEntity.installState == com.example.data.InstallState.INSTALLED) {
                            Surface(color = MaterialTheme.colorScheme.tertiaryContainer, shape = MaterialTheme.shapes.small) {
                                Text(text = "Installed", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.onTertiaryContainer, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }

                    // Download logic
                    var selectedAssetUrl by remember { mutableStateOf(appEntity.apkDownloadUrl) }
                    
                    val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
                    val adapter = moshi.adapter<List<ApkAsset>>(Types.newParameterizedType(List::class.java, ApkAsset::class.java))
                    val assets = appEntity.availableApkAssetsJson?.let { adapter.fromJson(it) } ?: emptyList()

                    if (assets.size > 1) {
                        Text("Select APK:", style = MaterialTheme.typography.labelLarge)
                        var expanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(
                            expanded = expanded,
                            onExpandedChange = { expanded = !expanded }
                        ) {
                            OutlinedTextField(
                                value = assets.find { it.downloadUrl == selectedAssetUrl }?.name ?: "Select APK",
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                                modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                assets.forEach { asset ->
                                    DropdownMenuItem(
                                        text = { Text(asset.name) },
                                        onClick = {
                                            selectedAssetUrl = asset.downloadUrl
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    val downloadStates by viewModel.downloadStates.collectAsState()
                    val currentDownloadState = downloadStates[repoFullName]

                    var downloadedFileUri by remember(currentDownloadState) { 
                        mutableStateOf(
                            if (currentDownloadState is DownloadState.Success) {
                                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", currentDownloadState.file)
                            } else null
                        ) 
                    }
                    
                    val canInstall = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        context.packageManager.canRequestPackageInstalls()
                    } else {
                        true
                    }
                    
                    if (currentDownloadState is DownloadState.InProgress) {
                        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            val percent = currentDownloadState.percent
                            if (percent != null) {
                                LinearProgressIndicator(
                                    progress = { percent / 100f },
                                    modifier = Modifier.fillMaxWidth().height(8.dp),
                                    color = MaterialTheme.colorScheme.secondary,
                                    trackColor = MaterialTheme.colorScheme.secondaryContainer
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("$percent% • ${currentDownloadState.bytesDownloaded / 1024 / 1024} MB / ${currentDownloadState.totalBytes / 1024 / 1024} MB", style = MaterialTheme.typography.bodySmall)
                            } else {
                                CircularProgressIndicator(color = MaterialTheme.colorScheme.secondary)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("${currentDownloadState.bytesDownloaded / 1024} KB downloaded...", style = MaterialTheme.typography.bodySmall)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = { viewModel.cancelDownload(repoFullName) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Cancel", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    } else {
                        Button(
                            onClick = {
                                if (downloadedFileUri != null) {
                                    // Install
                                    if (canInstall) {
                                        installApk(context, downloadedFileUri!!)
                                    } else {
                                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                            val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                                                data = "package:${context.packageName}".toUri()
                                            }
                                            context.startActivity(intent)
                                        }
                                    }
                                } else {
                                    // Download
                                    selectedAssetUrl?.let { url ->
                                        viewModel.startDownload(repoFullName, url, appEntity.displayName ?: "app")
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            val buttonText = if (downloadedFileUri != null) {
                                "Install"
                            } else if (appEntity.installState == com.example.data.InstallState.UPDATE_AVAILABLE) {
                                "Update"
                            } else {
                                "Download"
                            }
                            Text(buttonText, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (currentDownloadState is DownloadState.Error) {
                        Text(
                            "Download failed: ${currentDownloadState.message}", 
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                } else {
                    Text(
                        text = "App unavailable: ${appEntity.fetchStatus.name}",
                        color = MaterialTheme.colorScheme.error
                    )
                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, "https://github.com/${appEntity.repoFullName}".toUri())
                            context.startActivity(intent)
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer)
                    ) {
                        Text("Open GitHub Repo", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }

                HorizontalDivider()

                Text("Description", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                Text(appEntity.description ?: "No description available", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground)
            }
        }
    }
}

fun isAppInstalled(context: Context, packageName: String?): Boolean {
    if (packageName == null) return false
    return try {
        context.packageManager.getPackageInfo(packageName, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }
}

fun installApk(context: Context, uri: Uri) {
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/vnd.android.package-archive")
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
    }
    context.startActivity(intent)
}
