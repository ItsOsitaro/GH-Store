package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val settingsManager = viewModel.settingsManager

    var pat by remember { mutableStateOf(settingsManager.getPat() ?: "") }
    var showSnackbar by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("GitHub Settings", style = MaterialTheme.typography.titleMedium)

            OutlinedTextField(
                value = pat,
                onValueChange = {
                    pat = it
                    settingsManager.setPat(it.ifBlank { null })
                },
                label = { Text("Personal Access Token (Optional)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            val activeTokenStatus = when {
                pat.isNotBlank() -> "Using your token"
                com.example.Constants.DEFAULT_GITHUB_TOKEN.isNotBlank() -> "Using built-in token"
                else -> "No token — limited to 60 requests/hour"
            }

            Text(
                activeTokenStatus,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )

            Text(
                "Used to increase GitHub API rate limit from 60 to 5000 requests/hour.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))
            
            Button(
                onClick = {
                    viewModel.clearCache()
                    viewModel.syncApps(forceRefresh = true)
                    showSnackbar = true
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Clear Cache and Refetch")
            }
            
            if (showSnackbar) {
                Text("Cache cleared and refetch started.", color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
