package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppEntity
import com.example.data.AppRepository
import com.example.data.SettingsManager
import com.example.data.SyncStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import com.example.data.DownloadState

class MainViewModel(
    private val repository: AppRepository,
    val settingsManager: SettingsManager
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _sortBy = MutableStateFlow(SortBy.ALPHABETICAL)
    val sortBy: StateFlow<SortBy> = _sortBy

    private val _downloadStates = MutableStateFlow<Map<String, DownloadState>>(emptyMap())
    val downloadStates: StateFlow<Map<String, DownloadState>> = _downloadStates

    private val downloadJobs = mutableMapOf<String, Job>()

    fun startDownload(repoFullName: String, url: String, title: String) {
        val job = viewModelScope.launch {
            repository.downloadApk(url, title).collect { state ->
                _downloadStates.value = _downloadStates.value.toMutableMap().apply {
                    put(repoFullName, state)
                }
            }
        }
        downloadJobs[repoFullName] = job
    }

    fun cancelDownload(repoFullName: String) {
        downloadJobs[repoFullName]?.cancel()
        downloadJobs.remove(repoFullName)
        _downloadStates.value = _downloadStates.value.toMutableMap().apply {
            put(repoFullName, DownloadState.Cancelled)
        }
    }

    fun clearDownloadState(repoFullName: String) {
        _downloadStates.value = _downloadStates.value.toMutableMap().apply {
            remove(repoFullName)
        }
    }

    val syncStatus: StateFlow<SyncStatus> = repository.syncStatus
        .stateIn(viewModelScope, SharingStarted.Lazily, SyncStatus.Idle)

    val apps: StateFlow<List<AppEntity>> = combine(
        repository.getAllApps(),
        _searchQuery,
        _sortBy
    ) { appsList, query, sort ->
        var filtered = appsList
        if (query.isNotBlank()) {
            filtered = filtered.filter { 
                it.displayName?.contains(query, ignoreCase = true) == true || 
                it.repoFullName.contains(query, ignoreCase = true) 
            }
        }
        
        when (sort) {
            SortBy.ALPHABETICAL -> filtered.sortedBy { it.displayName?.lowercase() ?: "" }
            SortBy.RECENTLY_UPDATED -> filtered.sortedByDescending { it.publishedAt ?: "" }
            SortBy.UPDATES_FIRST -> filtered.sortedWith(
                compareBy<AppEntity> { it.installState != com.example.data.InstallState.UPDATE_AVAILABLE }
                    .thenBy { it.displayName?.lowercase() ?: "" }
            )
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val updatesAvailableCount: StateFlow<Int> = apps.map { list ->
        list.count { it.installState == com.example.data.InstallState.UPDATE_AVAILABLE }
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0)

    init {
        syncApps(forceRefresh = false)
    }

    fun syncApps(forceRefresh: Boolean = true) {
        viewModelScope.launch {
            repository.refreshInstallStates()
        }
        viewModelScope.launch {
            repository.syncApps(forceRefresh)
            repository.refreshInstallStates()
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateSortBy(sort: SortBy) {
        _sortBy.value = sort
    }
    
    fun getAppFlow(repoFullName: String) = repository.getAppFlow(repoFullName)

    fun clearCache() {
        viewModelScope.launch {
            repository.clearCache()
        }
    }

    class Factory(private val module: AppModule) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return MainViewModel(module.repository, module.settingsManager) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}

enum class SortBy {
    ALPHABETICAL, RECENTLY_UPDATED, UPDATES_FIRST
}
